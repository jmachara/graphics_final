#include <GL/glew.h>
#include <GL/freeglut.h>
#include "cyCodeBase/cyTriMesh.h"
#include "cyCodeBase/cyMatrix.h"
#include <stdio.h>
#include <string>
#include<fstream>
#include<iostream>
#include "cyCodeBase/cyGL.h"

//GLUT FUNCTIONS
void display_function();
void keyboard_function(unsigned char key, int x, int y);
void keyboard_up_function(unsigned char key, int x, int y);
void special_k_function(int key, int x, int y);
void special_k_up_function(int key, int x, int y);
void mouse_func(int x, int y);
void mouse_click_func(int button, int state, int x, int y);
void mouse_passive_func(int x, int y);
void idle_function();
void wind_reshape(int x, int y);
//HELPER FUNCTIONS
	//Initializations
void InitializeWindow();
void InitializeGlew();
void InitializePrograms();
void InitializeVao();
void InitializeGlutFuncs();
	//Object
void ComputeObjectMiddle();
std::vector<cy::Vec3f> build_object_buffer(cyTriMesh mesh);
std::vector<cy::Vec3f> build_norm_buffer(cyTriMesh mesh);
std::vector<cy::Vec2f> build_texCoord_buffer(cyTriMesh mesh);
void render_object();
	//Matrices
cy::Matrix4f create_mvp(float mid, double rot_x, double rot_z, float distance);
cy::Matrix3f create_norm_mv(float mid, double rot_x, double rot_z, float distance);
	//program
void set_uniforms();
void set_vao();
//VARIABLES
	//Program
cy::GLSLProgram prog;
cy::GLSLProgram prog2;
	//Window
int window_width = 1920;
int window_height = 1080;
	//Vao
GLuint vao;
	//Object
cyTriMesh mesh = cyTriMesh();
int object_mid;
double rotx = 0;
double rotz = 0;
int obj_buff_size;
int norm_buff_size;
	//Camera
float cam_dist = 50;
float fov = .7;
cy::Vec3f camera_pos = cy::Vec3f(0, 0, cam_dist);
	//Mouse
int mouse_x;
int mouse_y;
bool right_click = false;
	//Texture
cy::GLRenderTexture2D edge_buff;
float off = 2;
//main function
int main(int argc, char** argv)
{
	//Initialize
	glutInit(&argc, argv);
	InitializeWindow();
	InitializeGlew();
	InitializePrograms();
	InitializeVao();
	//Object from Command Line
	if (argc > 1)
	{
		mesh.LoadFromFileObj(argv[1]);
		ComputeObjectMiddle();

		set_vao();
	}
	set_uniforms();
	//Set Glut Functions
	InitializeGlutFuncs();
	glutMainLoop();
	return 0;

}
//helper functions
void InitializeWindow()
{
	glutInitContextVersion(4, 5);
	glutInitContextFlags(GLUT_DEBUG);
	glutInitWindowSize(window_width, window_height);
	glutInitWindowPosition(0, 0);
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA | GLUT_DEPTH);
	glutCreateWindow("Jack's GLUT");
}
void InitializeGlew()
{
	GLenum err = glewInit();
	if (GLEW_OK != err)
	{
		fprintf(stderr, "Error: %s\n", glewGetErrorString(err));
	}
}
void InitializePrograms()
{
	prog.BuildFiles("shader.vert", "shader.frag");
	prog2.BuildFiles("gBuff.vert", "gBuff.frag");

}
void InitializeVao()
{
	glGenVertexArrays(1, &vao);
	glBindVertexArray(vao);
}
void InitializeGlutFuncs()
{
	glutDisplayFunc(display_function);
	glutKeyboardFunc(keyboard_function);
	glutKeyboardUpFunc(keyboard_up_function);
	glutIdleFunc(idle_function);
	glutMotionFunc(mouse_func);
	glutMouseFunc(mouse_click_func);
	glutPassiveMotionFunc(mouse_passive_func);
	glutSpecialFunc(special_k_function);
	glutReshapeFunc(wind_reshape);
	glutSpecialUpFunc(special_k_up_function);
	glClearColor(.3, .3, .3, 1);
}
void ComputeObjectMiddle()
{
	mesh.ComputeBoundingBox();
	while (!mesh.IsBoundBoxReady()) {}
	cy::Vec3f low_bound = mesh.GetBoundMin();
	cy::Vec3f high_bound = mesh.GetBoundMax();
	object_mid = (high_bound[2] - low_bound[2])/2;
}
void set_uniforms()
{
	//program 1
	prog["mvp"] = create_mvp(object_mid,rotx,rotz,cam_dist);
	prog["norm_mv"] = create_norm_mv(object_mid, rotx, rotz, cam_dist);
	prog["texOff"] = cy::Vec2f(off,off);
	prog["dim"] = cy::Vec2f(window_width,window_height);
	prog["tex"] = 0;
	//program 2
	prog2["mvp"] = create_mvp(object_mid, rotx, rotz, cam_dist);
	prog2["norm_mv"] = create_norm_mv(object_mid, rotx, rotz, cam_dist);

}
void set_vao()
{
	//Object Buffer 0 
	GLuint object_buff;
	glGenBuffers(1, &object_buff);
	std::vector<cy::Vec3f> obj_buff = build_object_buffer(mesh);
	glBindBuffer(GL_ARRAY_BUFFER, object_buff);
	glBufferData(GL_ARRAY_BUFFER, sizeof(cy::Vec3f) * mesh.NF() * 3, &obj_buff.front(), GL_STATIC_DRAW);
	//norm buffer 1
	GLuint norm_buff;
	glGenBuffers(1, &norm_buff);
	std::vector<cy::Vec3f> n_buff = build_norm_buffer(mesh);
	glBindBuffer(GL_ARRAY_BUFFER, norm_buff);
	glBufferData(GL_ARRAY_BUFFER, 3 * sizeof(cy::Vec3f) * mesh.NF(), &n_buff.front(), GL_STATIC_DRAW);
	//texCoord buffer 2
	GLuint tex_buff;
	glGenBuffers(1, &tex_buff);
	std::vector<cy::Vec2f> t_buff = build_texCoord_buffer(mesh);
	glBindBuffer(GL_ARRAY_BUFFER, tex_buff);
	glBufferData(GL_ARRAY_BUFFER, 3 * sizeof(cy::Vec2f) * mesh.NF(), &t_buff.front(), GL_STATIC_DRAW);
	
	glVertexArrayVertexBuffer(vao, 0, object_buff, 0, sizeof(cy::Vec3f));
	glVertexArrayAttribBinding(vao, 0, 0);
	glVertexArrayAttribFormat(vao, 0, 3, GL_FLOAT, GL_FALSE, 0);
	glVertexArrayBindingDivisor(vao, 0, 0);
	glEnableVertexArrayAttrib(vao, 0);

	glVertexArrayVertexBuffer(vao, 1, norm_buff, 0, sizeof(cy::Vec3f));
	glVertexArrayAttribBinding(vao, 1, 1);
	glVertexArrayAttribFormat(vao, 1, 3, GL_FLOAT, GL_FALSE, 0);
	glVertexArrayBindingDivisor(vao, 1, 0);
	glEnableVertexArrayAttrib(vao, 1);

	glVertexArrayVertexBuffer(vao, 2, tex_buff, 0, sizeof(cy::Vec2f));
	glVertexArrayAttribBinding(vao, 2, 2);
	glVertexArrayAttribFormat(vao, 2, 3, GL_FLOAT, GL_FALSE, 0);
	glVertexArrayBindingDivisor(vao, 2, 0);
	glEnableVertexArrayAttrib(vao, 2);
}
std::vector<cy::Vec3f> build_object_buffer(cyTriMesh mesh)
{
	int tri_points = mesh.NF();
	std::vector<cy::Vec3f> triangles;
	obj_buff_size = 3 * tri_points;
	for (int i = 0; i < tri_points; i++)
	{
		cy::TriMesh::TriFace face = mesh.F(i);
		triangles.push_back(mesh.V(face.v[0]));
		triangles.push_back(mesh.V(face.v[1]));
		triangles.push_back(mesh.V(face.v[2]));
	}
	return triangles;
}
std::vector<cy::Vec3f> build_norm_buffer(cyTriMesh mesh)
{
	int faces = mesh.NF();
	std::vector<cy::Vec3f> norms;
	norm_buff_size = 3 * faces;
	for (int i = 0; i < faces; i++)
	{
		cy::TriMesh::TriFace face = mesh.F(i);
		norms.push_back(mesh.VN(face.v[0]));
		norms.push_back(mesh.VN(face.v[1]));
		norms.push_back(mesh.VN(face.v[2]));
	}

	return norms;
}
std::vector<cy::Vec2f> build_texCoord_buffer(cyTriMesh mesh)
{
	int faces = mesh.NF();
	std::vector<cy::Vec2f> coords;
	norm_buff_size = 3 * faces;
	for (int i = 0; i < faces; i++)
	{
		cy::TriMesh::TriFace face = mesh.FT(i);
		cy::Vec3f texture1 = mesh.VT(face.v[0]);
		cy::Vec3f texture2 = mesh.VT(face.v[1]);
		cy::Vec3f texture3 = mesh.VT(face.v[2]);
		coords.push_back(texture1.XY());
		coords.push_back(texture2.XY());
		coords.push_back(texture3.XY());
	}

	return coords;
}
cy::Matrix4f create_mvp(float mid, double rot_x, double rot_z, float distance)
{
	cy::Vec3f cam_pos = { 0,0,distance };
	cy::Vec3f target = { 0,0,0 };
	cy::Vec3f cam_dir = (cam_pos - target).GetNormalized();
	cy::Vec3f up = { 0,1,0 };
	cy::Vec3f cam_r = up.Cross(cam_dir);
	cy::Vec3f cam_u = cam_dir.Cross(cam_r);
	cy::Matrix4f view = cy::Matrix4f::View(cam_pos, target, cam_u);
	cy::Matrix4f trans = cy::Matrix4f::Translation({ 0,0,-mid });
	cy::Matrix4f rtrans = cy::Matrix4f::Translation({ 0,0,mid });
	cy::Matrix3f xRot = cy::Matrix3f::RotationX(rot_x);
	cy::Matrix3f zRot = cy::Matrix3f::RotationZ(rot_z);
	cy::Matrix4f rot = rtrans * xRot * zRot * trans;
	cy::Matrix4f proj = cy::Matrix4f::Perspective(fov, float(window_width) / float(window_height), 10.0f, 1000.0f);

	return proj * view * rot;
}
cy::Matrix3f create_norm_mv(float mid, double rot_x, double rot_z, float distance)
{
	cy::Vec3f cam_pos = { 0,0,distance};
	cy::Vec3f target = { 0,0,0 };
	cy::Vec3f cam_dir = (cam_pos - target).GetNormalized();
	cy::Vec3f up = { 0,1,0 };
	cy::Vec3f cam_r = up.Cross(cam_dir);
	cy::Vec3f cam_u = cam_dir.Cross(cam_r);
	cy::Matrix4f trans = cy::Matrix4f::Translation({ 0,0,-mid });
	cy::Matrix4f rtrans = cy::Matrix4f::Translation({ 0,0,mid });
	cy::Matrix3f xRot = cy::Matrix3f::RotationX(rot_x);
	cy::Matrix3f zRot = cy::Matrix3f::RotationZ(rot_z);
	cy::Matrix4f view = cy::Matrix4f::View(cam_pos, target, cam_u);
	cy::Matrix4f rot = rtrans * xRot * zRot * trans;
	cy::Matrix4f mv = (view * rot).GetInverse().GetTranspose();
	return mv.GetSubMatrix3();
}
void render_object()
{
	prog.Bind();
	edge_buff.BindTexture();
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glDrawArrays(GL_TRIANGLES, 0, obj_buff_size);
}
void render_buffer()
{
	prog2.Bind();
	edge_buff.Initialize(true, 3, window_width, window_height);
	edge_buff.Bind();
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glDrawArrays(GL_TRIANGLES, 0, obj_buff_size);
	edge_buff.Unbind();
	edge_buff.BuildTextureMipmaps();
	edge_buff.SetTextureAnisotropy(21);
	edge_buff.SetTextureFilteringMode(GL_LINEAR_MIPMAP_LINEAR, GL_LINEAR_MIPMAP_LINEAR);
}
//glut functions
void display_function()
{
	glEnable(GL_DEPTH_TEST);
	render_buffer();
	render_object();
	glutSwapBuffers();
}
void keyboard_function(unsigned char key, int x, int y)
{
	switch (key) {
	case 27://esc
		glutLeaveMainLoop();
		break;
	}
	glutPostRedisplay();

}
void keyboard_up_function(unsigned char key, int x, int y)
{
}
void special_k_function(int key, int x, int y)
{

}
void special_k_up_function(int key, int x, int y)
{

}
void mouse_func(int x, int y)
{
	if (right_click)
	{
		cam_dist -= (x - mouse_x) / 2;
	}
	else
	{
		if (x - mouse_x != 0)
		{
			rotz += ((x - mouse_x)) * 3.14 / 180;
		}
		if (y - mouse_y != 0)
		{
			rotx += ((y - mouse_y) * 3.14) / 180;

		}
	}
	set_uniforms();
	mouse_y = y;
	mouse_x = x;
	glutPostRedisplay();
}
void mouse_click_func(int button, int state, int x, int y)
{
	if (button == 0)
	{
		mouse_x = x;
		mouse_y = y;
	}
	else
	{
		right_click = !right_click;
		mouse_x = x;
	}
	glutPostRedisplay();

}
void mouse_passive_func(int x, int y)
{
}
void idle_function()
{

}
void wind_reshape(int x, int y)
{
	window_width = x;
	window_height = y;
	set_uniforms();
	glViewport(0, 0, window_width, window_height);
	set_uniforms();
	glutPostRedisplay();
}
